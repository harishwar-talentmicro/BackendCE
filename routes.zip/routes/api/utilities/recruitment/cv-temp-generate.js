var express = require('express');
var router = express.Router();
var fs = require('fs');
var stream = require('stream');
var http = require('https');
var Docxtemplater = require('docxtemplater');
var ImageModule = require('docxtemplater-image-module');
var gm = require('gm').subClass({ imageMagick: true });

var PDFClient = require('../pdf-client.js');


router.post('/cv_generate',function(req,res,next){
    var if_not_ref = 'References available on request.';
    var hob = false;
    var we = false;
    var ad = false;
    var ref = false;
    var ks = false;
    var edu = false;
    var aoc = false;
    var reference = req.body.reference;
    var imageFullPath = 'https://storage.googleapis.com/ezeone/';
    var imagePath = (req.body.imagePath) ? imageFullPath + req.body.imagePath : imageFullPath;
    req.body.saveFlag = (req.body.saveFlag) ? 1 : 0;
    if (req.body.hobbies){
        hob = true;
    }
    if (req.body.key_skills){
        ks = true;
    }
    if (req.body.work_exp.length > 0){
        we = true;
    }
    if (req.body.education.length > 0){
        edu = true;
    }
    if (req.body.additional_info.length > 0){
        ad = true;
    }
    if (req.body.career.length > 0){
        aoc = true;
    }
    //if (reference.ref_name && reference.ref_name1){
    //    ref = true;
    //    if_not_ref = '';
    //}
    if (req.body.work_exp.length > 0){
        ref = true;
        if_not_ref = '';
    }
    //var abc = req.body.flag;
    //var exp;
    //for (var a = 0; a > abc.length; a++){
    //    exp = (parseInt(abc[a].total_exp) <= 1) ? abc[a].total_exp+' Year' : abc[a].total_exp+' Years';
    //    console.log(exp);
    //}
    http.get(imagePath, function(response){
        var bufs = [];
        response.on('data', function(d){ bufs.push(d); });
        response.on('end', function() {
            var bufImg = Buffer.concat(bufs);
            var buf = Buffer.concat(bufs);
            gm(buf).size(function(err,size){
                console.log("size",size);
                console.log("err",err);
                if(size && size.height && size.width){
                    var opts = {};
                    opts.centered = false;
                    opts.getSize=function(buf) {
                        return [150,150];
                    };
                    opts.getImage = function () {
                        return bufImg;
                    };
                    var content = fs.readFileSync(__dirname + "/cv_template.docx", "binary");
                    var doc = new Docxtemplater(content);
                    var imageModule=new ImageModule(opts);
                    doc.attachModule(imageModule);
                    doc.setData({
                        "name": req.body.name,
                        "ezeoneid": req.body.ezeoneid,
                        "phone": req.body.phone,
                        "email": req.body.email,
                        "v_st": req.body.v_st,
                        "objective": req.body.objective,
                        "key_skills": req.body.key_skills,
                        "career": req.body.career,
                        "education": req.body.education,
                        "additional_info": req.body.additional_info,
                        "work_exp": req.body.work_exp,
                        "hobbies": req.body.hobbies,
                        "full_name": req.body.full_name,
                        "address": req.body.address,
                        "passport": (req.body.passport) ? req.body.passport : '',
                        "other_info": (req.body.other_info) ? req.body.other_info : '',
                        "dob": req.body.dob,
                        "gender": req.body.gender,
                        "if_not_ref": if_not_ref,
                        "image": req.body.imagePath,
                        "reference": req.body.reference,
                        "total_exp": (parseInt(req.body.total_exp) <= 1) ? req.body.total_exp+' YEAR' : req.body.total_exp+' YEARS',
                        "ezeone_pin":req.body.ezeoneid+'.CV.'+req.body.pin,
                        "hob":hob,
                        "we":we,
                        "ad":ad,
                        "edu":edu,
                        "ks":ks,
                        "ref":ref,
                        "aoc":aoc
                    });
                    doc.render();
                    var buf = doc.getZip().generate({type: "nodebuffer"});

                    //var pdfClient = new PDFClient(req.CONFIG);
                    //pdfClient.convertToPdf(buf,function(err,pdfBuffer){
                    //    if(err){
                    //        console.log(err);
                    //        res.status(500).send('');
                    //        return;
                    //    }
                    //    var bufferStream = new stream.PassThrough();
                    //    bufferStream.end(pdfBuffer);
                    //    res.setHeader('Content-disposition', 'attachment; filename=resume.pdf');
                    //    res.setHeader('Content-type', "application/pdf");
                    //    bufferStream.pipe(res);
                    //});

                    var bufferStream = new stream.PassThrough();
                    bufferStream.end(buf);
                    //res.setHeader('Content-disposition', 'attachment; filename=resume.docx');
                    //res.setHeader('Content-type', "application/octet-stream");
                    //bufferStream.pipe(res);
                    //console.log(bufferStream,"bufferStream1");

                    if(req.body.saveFlag == 0){
                        res.setHeader('Content-disposition', 'attachment; filename=resume.docx');
                        res.setHeader('Content-type', "application/octet-stream");
                        bufferStream.pipe(res);
                    }
                    else{
                        var attachmentFileName = req.st.libs.uuid.v4()+'.docx';
                        req.st.uploadDocumentToCloud(attachmentFileName,bufferStream,function(err){
                            if (!err) {
                                var procParams = [
                                    req.db.escape(req.body.token) ,
                                    req.db.escape(attachmentFileName),
                                ];
                                var procQuery = 'CALL psave_resumeurl(' + procParams.join(',') + ')';
                                console.log("procQuery",procQuery);
                                req.db.query(procQuery, function (err, saveResumeResults){
                                    if (!err) {
                                        //var attachmentLink = req.CONFIG.CONSTANT.GS_URL +
                                        //    req.CONFIG.CONSTANT.STORAGE_BUCKET + '/' + attachmentFileName;
                                        console.log("resume saved successfully");
                                        res.setHeader('Content-disposition', 'attachment; filename=resume.docx');
                                        res.setHeader('Content-type', "application/octet-stream");
                                        var bufferStream1 = new stream.PassThrough();
                                        bufferStream1.end(buf);
                                        bufferStream1.pipe(res);
                                    }
                                    else{
                                        console.log("resume not saved successfully");
                                    }
                                });

                            }
                            else{
                                console.log("resume not uploaded on cloud");
                            }
                        });

                    }
                }
                else{
                    console.log("imagePath4",imagePath);
                    content = fs.readFileSync(__dirname + "/cv_template.docx", "binary");
                    var doc = new Docxtemplater(content);

                    doc.setData({
                        "name": req.body.name,
                        "ezeoneid": req.body.ezeoneid,
                        "phone": req.body.phone,
                        "email": req.body.email,
                        "v_st": req.body.v_st,
                        "objective": req.body.objective,
                        "key_skills": req.body.key_skills,
                        "career": req.body.career,
                        "education": req.body.education,
                        "additional_info": req.body.additional_info,
                        "work_exp": req.body.work_exp,
                        "hobbies": req.body.hobbies,
                        "full_name": req.body.full_name,
                        "address": req.body.address,
                        "passport": (req.body.passport) ? req.body.passport : '',
                        "other_info": (req.body.other_info) ? req.body.other_info : '',
                        "dob": req.body.dob,
                        "gender": req.body.gender,
                        "if_not_ref": if_not_ref,
                        "%image": '',
                        "reference": req.body.reference,
                        "total_exp": (parseInt(req.body.total_exp) <= 1) ? req.body.total_exp+' Year' : req.body.total_exp+' Years',
                        "ezeone_pin":req.body.ezeoneid+'.CV.'+req.body.pin,
                        "hob":hob,
                        "we":we,
                        "ad":ad,
                        "edu":edu,
                        "ks":ks,
                        "ref":ref,
                        "aoc":aoc
                    });
                    doc.render();
                    var buf = doc.getZip().generate({type: "nodebuffer"});
                    console.log(buf.length);
                    var bufferStream = new stream.PassThrough();
                    bufferStream.end(buf);

                    if(req.body.saveFlag == 0){
                        res.setHeader('Content-disposition', 'attachment; filename=resume.docx');
                        res.setHeader('Content-type', "application/octet-stream");
                        bufferStream.pipe(res);
                    }
                    else{
                        var attachmentFileName = req.st.libs.uuid.v4()+'.docx';
                        req.st.uploadDocumentToCloud(attachmentFileName,bufferStream,function(err){
                            if (!err) {
                                var procParams = [
                                    req.db.escape(req.body.token) ,
                                    req.db.escape(attachmentFileName),
                                ];
                                var procQuery = 'CALL psave_resumeurl(' + procParams.join(',') + ')';
                                console.log("procQuery",procQuery);
                                req.db.query(procQuery, function (err, saveResumeResults){
                                    if (!err) {
                                        //var attachmentLink = req.CONFIG.CONSTANT.GS_URL +
                                        //    req.CONFIG.CONSTANT.STORAGE_BUCKET + '/' + attachmentFileName;
                                       console.log("resume saved successfully");
                                        res.setHeader('Content-disposition', 'attachment; filename=resume.docx');
                                        res.setHeader('Content-type', "application/octet-stream");
                                        var bufferStream1 = new stream.PassThrough();
                                        bufferStream1.end(buf);
                                        bufferStream1.pipe(res);
                                    }
                                    else{
                                        console.log("resume not saved successfully");
                                    }
                                });

                            }
                            else{
                                console.log("resume not uploaded on cloud");
                            }
                        });


                    }


                    //var pdfClient = new PDFClient(req.CONFIG);
                    //pdfClient.convertToPdf(buf,function(err,pdfBuffer){
                    //    if(err){
                    //        console.log(err);
                    //        res.status(500).send('');
                    //        return;
                    //    }
                    //    var bufferStream = new stream.PassThrough();
                    //    bufferStream.end(pdfBuffer);
                    //    res.setHeader('Content-disposition', 'attachment; filename=resume.pdf');
                    //    res.setHeader('Content-type', "application/pdf");
                    //    bufferStream.pipe(res);
                    //});

                    //fs.writeFileSync(__dirname+"/output.docx",buf);
                    //res.status(200).json("Success");
                }
            });
        });
        response.on('error',function(){
            var content = fs.readFileSync(__dirname + "/cv_template.docx", "binary");
            var doc = new Docxtemplater(content);
            doc.setData({
                "name": req.body.name,
                "ezeoneid": req.body.ezeoneid,
                "phone": req.body.phone,
                "email": req.body.email,
                "v_st": req.body.v_st,
                "objective": req.body.objective,
                "key_skills": req.body.key_skills,
                "career": req.body.career,
                "education": req.body.education,
                "additional_info": req.body.additional_info,
                "work_exp": req.body.work_exp,
                "hobbies": req.body.hobbies,
                "full_name": req.body.full_name,
                "address": req.body.address,
                "passport": (req.body.passport) ? req.body.passport : '',
                "other_info": (req.body.other_info) ? req.body.other_info : '',
                "dob": req.body.dob,
                "gender": req.body.gender,
                "if_not_ref": if_not_ref,
                "%image": '',
                "reference": req.body.reference,
                "total_exp": (parseInt(req.body.total_exp) <= 1) ? req.body.total_exp+' Year' : req.body.total_exp+' Years',
                "ezeone_pin":req.body.ezeoneid+'.CV.'+req.body.pin,
                "hob":hob,
                "we":we,
                "ad":ad,
                "edu":edu,
                "ks":ks,
                "ref":ref,
                "aoc":aoc
            });
            doc.render();
            var buf = doc.getZip().generate({type: "nodebuffer"});
            console.log(buf.length);
            var bufferStream = new stream.PassThrough();
            bufferStream.end(buf);


            if(req.body.saveFlag == 0){
                res.setHeader('Content-disposition', 'attachment; filename=resume.docx');
                res.setHeader('Content-type', "application/octet-stream");
                bufferStream.pipe(res);
            }
            else{
                var attachmentFileName = req.st.libs.uuid.v4()+'.docx';
                req.st.uploadDocumentToCloud(attachmentFileName,bufferStream,function(err){
                    if (!err) {
                        var procParams = [
                            req.db.escape(req.body.token) ,
                            req.db.escape(attachmentFileName)
                        ];
                        var procQuery = 'CALL psave_resumeurl(' + procParams.join(',') + ')';
                        console.log("procQuery",procQuery);
                        req.db.query(procQuery, function (err, saveResumeResults){
                            if (!err) {
                                //var attachmentLink = req.CONFIG.CONSTANT.GS_URL +
                                //    req.CONFIG.CONSTANT.STORAGE_BUCKET + '/' + attachmentFileName;
                                console.log("resume saved successfully");
                                res.setHeader('Content-disposition', 'attachment; filename=resume.docx');
                                res.setHeader('Content-type', "application/octet-stream");
                                var bufferStream1 = new stream.PassThrough();
                                bufferStream1.end(buf);
                                bufferStream1.pipe(res);
                            }
                            else{
                                console.log("resume not saved successfully");
                            }
                        });

                    }
                    else{
                        console.log("resume not uploaded on cloud");
                    }
                });


            }


            //res.setHeader('Content-disposition', 'attachment; filename=resume.docx');
            //res.setHeader('Content-type', "application/octet-stream");
            //bufferStream.pipe(res);
            //console.log(bufferStream,"bufferStream3");
            //var pdfClient = new PDFClient(req.CONFIG);
            //pdfClient.convertToPdf(buf,function(err,pdfBuffer){
            //    if(err){
            //        console.log(err);
            //        res.status(500).send('');
            //        return;
            //    }
            //    var bufferStream = new stream.PassThrough();
            //    bufferStream.end(pdfBuffer);
            //    res.setHeader('Content-disposition', 'attachment; filename=resume.pdf');
            //    res.setHeader('Content-type', "application/pdf");
            //    bufferStream.pipe(res);
            //});

            //fs.writeFileSync(__dirname+"/output.docx",buf);
            //res.status(200).json("Success");
        });
    });

    //var buffer = new Buffer('testbuffer');
    //var bufferStream = new stream.PassThrough();
    //bufferStream.end(buf);
    //res.setHeader('Content-disposition', 'attachment; filename=resume');
    //res.setHeader('Content-type', "application/msword");
    //bufferStream.pipe(res);
    //res.setHeader("Content-Type", "application/msword");res.status(200).send(buf,'binary');

});


router.post('/test_code',function(req,res,next){
    var if_not_ref = '';
    var reference = req.body.reference;
    if (reference.length < 1){
        if_not_ref = 'References available on request.';
    }
    var imagePath = (req.body.imagePath) ? "https://storage.googleapis.com/ezeone/"+ req.body.imagePath : 'https://storage.googleapis.com/ezeone/abc';
    http.get(imagePath, function(response){

        /**
         * @todo steam to buffer
         * @param response
         */
        var bufs = [];

        response.on('data', function(d){ bufs.push(d); });
        response.on('end', function() {
            var buf = Buffer.concat(bufs);
            var opts = {};
            opts.centered = false;
            opts.getImage = function () {
                return buf;
            };
            opts.getSize=function(buf) {
                return [150,150];
            };
            content = fs.readFileSync(__dirname + "/cv_template.docx", "binary");
            var doc = new Docxtemplater(content);
            var imageModule=new ImageModule(opts);
            doc.attachModule(imageModule);
            doc.setData({
                "name": req.body.name,
                "ezeoneid": req.body.ezeoneid,
                "phone": req.body.phone,
                "email": req.body.email,
                "v_st": "verified",
                "objective": req.body.objective,
                "key_skills": req.body.key_skills,
                "career": req.body.career,
                "education": req.body.education,
                "additional_info": req.body.additional_info,
                "work_exp": req.body.work_exp,
                "hobbies": req.body.hobbies,
                "full_name": req.body.full_name,
                "address": req.body.address,
                "passport_no": req.body.passport,
                "other_info": (req.body.other_info) ? req.body.other_info : '',
                "dob": req.body.dob,
                "gender": req.body.gender,
                "if_not_ref": if_not_ref,
                "image": imagePath,
                "reference": req.body.reference,
                //"reference2": req.body.reference2,
                "total_exp": (parseInt(req.body.total_exp) <= 1) ? req.body.total_exp+' Year' : req.body.total_exp+' Years'
            });
            doc.render();
            var buf = doc.getZip().generate({type: "nodebuffer"});
            fs.writeFileSync(__dirname+"/output.docx",buf);
            //unoconv.convert('/cv_template.docx','pdf', function(err,buffer){
            //    console.log("err",err);
            //    console.log("buffer",buffer);
            //    fs.writeFileSync(__dirname+"/output.pdf",buffer);
            //    res.status(200).json("Success");
            //});
            //fs.writeFileSync(__dirname+"/output.pdf",buf);
            res.status(200).json("Success");
        });
    });
    //var buffer = new Buffer('testbuffer');
    //var bufferStream = new stream.PassThrough();
    //bufferStream.end(buf);
    //res.setHeader('Content-disposition', 'attachment; filename=resume');
    //res.setHeader('Content-type', "application/msword");
    //bufferStream.pipe(res);
    //res.setHeader("Content-Type", "application/msword");res.status(200).send(buf,'binary');

});


module.exports = router;
