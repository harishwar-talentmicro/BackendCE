/**
 * Created by Jana1 on 06-04-2017.
 */


var LoginCtrl = {};
var error = {};

LoginCtrl.login = function(req,res,next){
    var response = {
        status : false,
        message : "Invalid credentials",
        data : null,
        error : null
    };
    var validationFlag = true;
    if (!req.query.token) {
        error.token = 'Invalid token';
        validationFlag *= false;
    }
    if (!req.query.EZEOneId)
    {
        error.token = 'Invalid EZEOneId';
        validationFlag *= false;
    }
    if (!req.query.password)
    {
        error.token = 'Invalid password';
        validationFlag *= false;
    }

    if (!validationFlag){
        response.error = error;
        response.message = 'Please check the errors';
        res.status(400).json(response);
        console.log(response);
    }
    req.st.validateHEToken(req.query.token,req.query.EZEOneId,req.query.password,function(err,tokenResult){
        if((!err) && tokenResult){
            console.log(tokenResult[0].heUserId, "heuserId") ;

            var procParams = [
                req.st.db.escape(tokenResult[0].heUserId)
            ];
            /**
             * Calling procedure to save form template
             * @type {string}
             */
            var procQuery = 'CALL HE_get_formList( ' + procParams.join(',') + ')';
            console.log(procQuery);
            req.db.query(procQuery,function(err,formList){
                console.log(err);
                if(!err && formList && formList[0] && formList[0][0]){
                    response.status = true;
                    response.message = "Form list loaded successfully";
                    response.error = null;
                    response.data = formList[0];
                    res.status(200).json(response);
                }
                else{
                    response.status = false;
                    response.message = "Error while getting formlist";
                    response.error = null;
                    response.data = null;
                    res.status(500).json(response);
                }
            });
        }
        else{
            res.status(401).json(response);
        }
    });
};

LoginCtrl.getHelloEZEUsers = function(req,res,next){
    var response = {
        status : false,
        message : "Invalid credentials",
        data : null,
        error : null
    };
    var validationFlag = true;
    if (!req.query.token) {
        error.token = 'Invalid token';
        validationFlag *= false;
    }
    if (!req.query.EZEOneId)
    {
        error.token = 'Invalid EZEOneId';
        validationFlag *= false;
    }
    if (!req.query.password)
    {
        error.token = 'Invalid password';
        validationFlag *= false;
    }
    if (!req.query.userFormMapId)
    {
        error.userFormMapId = 'Invalid userFormMapId';
        validationFlag *= false;
    }

    if (!validationFlag){
        response.error = error;
        response.message = 'Please check the errors';
        res.status(400).json(response);
        console.log(response);
    }

    req.st.validateHEToken(req.query.token,req.query.EZEOneId,req.query.password,function(err,tokenResult){
        if((!err) && tokenResult){

            var procParams = [
                req.st.db.escape(req.query.userFormMapId)
            ];
            /**
             * Calling procedure to save form template
             * @type {string}
             */
            var procQuery = 'CALL HE_get_accessUsersList( ' + procParams.join(',') + ')';
            console.log(procQuery);
            req.db.query(procQuery,function(err,userList){
                console.log(err);
                if(!err && userList && userList[0]){
                    response.status = true;
                    response.message = "Access user list loaded successfully";
                    response.error = null;
                    response.data = userList[0];
                    res.status(200).json(response);
                }
                else{
                    response.status = false;
                    response.message = "Error while getting user list";
                    response.error = null;
                    response.data = null;
                    res.status(500).json(response);
                }
            });
        }
        else{
            res.status(401).json(response);
        }
    });
};

LoginCtrl.getFormStatus = function(req,res,next){
    var response = {
        status : false,
        message : "Invalid credentials",
        data : null,
        error : null
    };
    var validationFlag = true;

    // req.query.APIKey = req.query.APIKey ? req.query.APIKey : "";
    req.query.EZEOneId = req.query.EZEOneId ? req.query.EZEOneId : "";
    req.query.password = req.query.password ? req.query.password : "";
    req.query.token = req.query.token ? req.query.token : "";

    if (!req.query.APIKey)
    {
        error.APIKey = 'Invalid APIKey';
        validationFlag *= false;
    }

    if (!validationFlag){
        response.error = error;
        response.message = 'Please check the errors';
        res.status(400).json(response);
        console.log(response);
    }
    else {
        req.st.validateHEToken(req.query.APIKey,req.query.EZEOneId,req.query.password,req.query.token,function(err,tokenResult){
            if((!err) && tokenResult){
                var procParams = [
                    req.st.db.escape(req.query.formTypeId),
                    req.st.db.escape(req.query.token),
                    req.st.db.escape(req.query.APIKey)
                ];

                /**
                 * Calling procedure to save form template
                 * @type {string}
                 */
                var procQuery = 'CALL WhatMate_get_StatusList( ' + procParams.join(',') + ')';
                console.log(procQuery);
                req.db.query(procQuery,function(err,taskList){
                    console.log(err);
                    if(!err && taskList && taskList[0]){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = taskList[0];
                        res.status(200).json(response);
                    }
                    else{
                        response.status = false;
                        response.message = "Error while getting data list";
                        response.error = null;
                        response.data = null;
                        res.status(500).json(response);
                    }
                });
            }
            else{
                res.status(401).json(response);
            }
        });
    }


};

LoginCtrl.getTasks = function(req,res,next){
    var response = {
        status : false,
        message : "Invalid credentials",
        data : null,
        error : null
    };
    var validationFlag = true;

    // req.query.APIKey = req.query.APIKey ? req.query.APIKey : "";
    req.query.EZEOneId = req.query.EZEOneId ? req.query.EZEOneId : "";
    req.query.password = req.query.password ? req.query.password : "";
    req.query.token = req.query.token ? req.query.token : "";

    if (!req.query.APIKey)
    {
        error.APIKey = 'Invalid APIKey';
        validationFlag *= false;
    }

    if (!validationFlag){
        response.error = error;
        response.message = 'Please check the errors';
        res.status(400).json(response);
        console.log(response);
    }
    else {
        req.st.validateHEToken(req.query.APIKey,req.query.EZEOneId,req.query.password,req.query.token,function(err,tokenResult){
            if((!err) && tokenResult){

                req.query.status = req.query.status ? req.query.status : 0;
                req.query.startDate = req.query.startDate ? req.query.startDate : null;
                req.query.endDate = req.query.endDate ? req.query.endDate : null;
                req.query.pageNo = (req.query.pageNo) ? (req.query.pageNo):1;
                req.query.limit = (req.query.limit) ? (req.query.limit):100;
                req.query.companyMasterId  = (req.query.companyMasterId) ? (req.query.companyMasterId):0;

                var procParams = [
                    req.st.db.escape(req.query.status),
                    req.st.db.escape(req.query.startDate),
                    req.st.db.escape(req.query.endDate),
                    req.st.db.escape(req.query.APIKey),
                    req.st.db.escape(req.query.pageNo),
                    req.st.db.escape(req.query.limit),
                    req.st.db.escape(tokenResult[0].masterid)
                ];
                /**
                 * Calling procedure to save form template
                 * @type {string}
                 */
                var procQuery = 'CALL WhatMate_get_taskList( ' + procParams.join(',') + ')';
                console.log(procQuery);
                req.db.query(procQuery,function(err,taskList){
                    console.log(err);
                    if(!err && taskList && taskList[0]){
                        response.status = true;
                        response.message = "Task list loaded successfully";
                        response.error = null;
                        response.data = {
                            taskList : taskList[0],
                            count : taskList[1][0].count
                        };
                        res.status(200).json(response);
                    }
                    else if(!err){
                        response.status = true;
                        response.message = "Task list loaded successfully";
                        response.error = null;
                        response.data = null;
                        res.status(200).json(response);
                    }
                    else{
                        response.status = false;
                        response.message = "Error while getting task list";
                        response.error = null;
                        response.data = null;
                        res.status(500).json(response);
                    }
                });
            }
            else{
                res.status(401).json(response);
            }
        });
    }


};

LoginCtrl.getMeeting = function(req,res,next){
    var response = {
        status : false,
        message : "Invalid credentials",
        data : null,
        error : null
    };
    var validationFlag = true;

    // req.query.APIKey = req.query.APIKey ? req.query.APIKey : "";
    req.query.EZEOneId = req.query.EZEOneId ? req.query.EZEOneId : "";
    req.query.password = req.query.password ? req.query.password : "";
    req.query.token = req.query.token ? req.query.token : "";

    if (!req.query.APIKey)
    {
        error.APIKey = 'Invalid APIKey';
        validationFlag *= false;
    }

    if (!validationFlag){
        response.error = error;
        response.message = 'Please check the errors';
        res.status(400).json(response);
        console.log(response);
    }
    else {
        req.st.validateHEToken(req.query.APIKey,req.query.EZEOneId,req.query.password,req.query.token,function(err,tokenResult){
            if((!err) && tokenResult){

                req.query.status = req.query.status ? req.query.status : 0;
                req.query.startDate = req.query.startDate ? req.query.startDate : null;
                req.query.endDate = req.query.endDate ? req.query.endDate : null;
                req.query.pageNo = (req.query.pageNo) ? (req.query.pageNo):1;
                req.query.limit = (req.query.limit) ? (req.query.limit):100;

                var procParams = [
                    req.st.db.escape(req.query.status),
                    req.st.db.escape(req.query.startDate),
                    req.st.db.escape(req.query.endDate),
                    req.st.db.escape(req.query.APIKey),
                    req.st.db.escape(req.query.pageNo),
                    req.st.db.escape(req.query.limit),
                    req.st.db.escape(tokenResult[0].masterid)
                ];
                /**
                 * Calling procedure to save form template
                 * @type {string}
                 */
                var procQuery = 'CALL WhatMate_get_MeetingList( ' + procParams.join(',') + ')';
                console.log(procQuery);
                req.db.query(procQuery,function(err,taskList){
                    console.log(err);
                    if(!err && taskList && taskList[0]){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = {
                            meetingList : taskList[0],
                            count : taskList[1][0].count
                        };
                        res.status(200).json(response);
                    }
                    else if(!err){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = null;
                        res.status(200).json(response);
                    }
                    else{
                        response.status = false;
                        response.message = "Error while getting data list";
                        response.error = null;
                        response.data = null;
                        res.status(500).json(response);
                    }
                });
            }
            else{
                res.status(401).json(response);
            }
        });
    }

};

LoginCtrl.getExpenseList = function(req,res,next){
    var response = {
        status : false,
        message : "Invalid credentials",
        data : null,
        error : null
    };
    var validationFlag = true;

    // req.query.APIKey = req.query.APIKey ? req.query.APIKey : "";
    req.query.EZEOneId = req.query.EZEOneId ? req.query.EZEOneId : "";
    req.query.password = req.query.password ? req.query.password : "";
    req.query.token = req.query.token ? req.query.token : "";

    if (!req.query.APIKey)
    {
        error.APIKey = 'Invalid APIKey';
        validationFlag *= false;
    }

    if (!validationFlag){
        response.error = error;
        response.message = 'Please check the errors';
        res.status(400).json(response);
        console.log(response);
    }
    else {
        req.st.validateHEToken(req.query.APIKey,req.query.EZEOneId,req.query.password,req.query.token,function(err,tokenResult){
            if((!err) && tokenResult){

                req.query.status = req.query.status ? req.query.status : 0;
                req.query.startDate = req.query.startDate ? req.query.startDate : null;
                req.query.endDate = req.query.endDate ? req.query.endDate : null;
                req.query.pageNo = (req.query.pageNo) ? (req.query.pageNo):1;
                req.query.limit = (req.query.limit) ? (req.query.limit):100;

                var procParams = [
                    req.st.db.escape(req.query.status),
                    req.st.db.escape(req.query.startDate),
                    req.st.db.escape(req.query.endDate),
                    req.st.db.escape(req.query.APIKey),
                    req.st.db.escape(req.query.pageNo),
                    req.st.db.escape(req.query.limit),
                    req.st.db.escape(tokenResult[0].masterid)
                ];
                /**
                 * Calling procedure to save form template
                 * @type {string}
                 */
                var procQuery = 'CALL WhatMate_get_ExpenseClaim( ' + procParams.join(',') + ')';
                console.log(procQuery);
                req.db.query(procQuery,function(err,expenseList){
                    console.log(err);
                    if(!err && expenseList && expenseList[0]){
                        // var output = [];
                        // for(var i = 0; i < expenseList[0].length; i++) {
                        //     var res1 = {};
                        //     res1.parentId = expenseList[0][i].parentId;
                        //     res1.title = expenseList[0][i].title;
                        //     res1.currencyId = expenseList[0][i].currencyId;
                        //     res1.currencyTitle = expenseList[0][i].currencyTitle;
                        //     res1.amount = expenseList[0][i].amount;
                        //     res1.createdDate = expenseList[0][i].createdDate;
                        //     res1.senderNotes = expenseList[0][i].senderNotes;
                        //     res1.approverNotes = expenseList[0][i].approvalNotes;
                        //     res1.amountSettled = expenseList[0][i].amountSettled;
                        //     res1.receiverNotes = expenseList[0][i].receiverNotes;
                        //     res1.status = expenseList[0][i].status;
                        //     res1.statusTitle = expenseList[0][i].statusTitle;
                        //     res1.senderName = expenseList[0][i].senderName;
                        //     res1.expenseCount = expenseList[0][i].expenseCount;
                        //     res1.transId = expenseList[0][i].transId;
                        //
                        //     // var expenseJSON = (expenseList[0][i].expenseList) ? JSON.parse(expenseList[0][i].expenseList) : "" ;
                        //     // var expenseOutput = [];
                        //     //
                        //     // for(var ii = 0; ii < expenseJSON.length; ii++) {
                        //     //     var expenseRes = {};
                        //     //     expenseRes.amount = expenseJSON[ii].amount;
                        //     //     expenseRes.expDate = expenseJSON[ii].expDate;
                        //     //     expenseRes.currencyId = expenseJSON[ii].currencyId;
                        //     //     expenseRes.particulars = expenseJSON[ii].particulars;
                        //     //     expenseRes.expenseTypeId = expenseJSON[ii].expenseTypeId;
                        //     //     expenseRes.currencySymbol = expenseJSON[ii].currencySymbol;
                        //     //     expenseRes.expenseTypeTitle = expenseJSON[ii].expenseTypeTitle;
                        //     //     expenseRes.attachment = (expenseJSON[ii].attachment) ? JSON.parse(expenseJSON[ii].attachment) : "" ;
                        //     //     expenseOutput.push(expenseRes)
                        //     // }
                        //     // res1.expenseList = expenseOutput;
                        //     output.push(res1);
                        // }
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = {
                            expenseList : expenseList[0],
                            count : expenseList[1][0].count
                        };
                        res.status(200).json(response);
                    }
                    else if(!err){
                        response.status = true;
                        response.message = "No data found";
                        response.error = null;
                        response.data = null ;
                        res.status(200).json(response);
                    }
                    else{
                        response.status = false;
                        response.message = "Error while getting data list";
                        response.error = null;
                        response.data = null;
                        res.status(500).json(response);
                    }
                });
            }
            else{
                res.status(401).json(response);
            }
        });
    }

};

LoginCtrl.getExpenseDetails = function(req,res,next){
    var response = {
        status : false,
        message : "Invalid credentials",
        data : null,
        error : null
    };
    var validationFlag = true;

    // req.query.APIKey = req.query.APIKey ? req.query.APIKey : "";
    req.query.EZEOneId = req.query.EZEOneId ? req.query.EZEOneId : "";
    req.query.password = req.query.password ? req.query.password : "";
    req.query.token = req.query.token ? req.query.token : "";

    if (!req.query.APIKey)
    {
        error.APIKey = 'Invalid APIKey';
        validationFlag *= false;
    }

    if (!validationFlag){
        response.error = error;
        response.message = 'Please check the errors';
        res.status(400).json(response);
        console.log(response);
    }
    else {
        req.st.validateHEToken(req.query.APIKey,req.query.EZEOneId,req.query.password,req.query.token,function(err,tokenResult){
            if((!err) && tokenResult){

                var procParams = [
                    req.st.db.escape(req.query.APIKey),
                    req.st.db.escape(tokenResult[0].masterid),
                    req.st.db.escape(req.query.transId)
                ];
                /**
                 * Calling procedure to save form template
                 * @type {string}
                 */
                var procQuery = 'CALL WhatMate_get_ExpenseDetails( ' + procParams.join(',') + ')';
                console.log(procQuery);
                req.db.query(procQuery,function(err,expenseList){

                    if(!err && expenseList && expenseList[0]){
                        var output = [];
                        var expenseJSON = (expenseList[0][0].expenses) ? JSON.parse(expenseList[0][0].expenses) : "" ;

                        for(var i = 0; i < expenseJSON.length; i++) {
                                var expenseRes = {};
                                console.log("expenseList[0][i].amount",expenseJSON[i].amount);
                                expenseRes.amount = expenseJSON[i].amount;
                                expenseRes.expDate = expenseJSON[i].expDate;
                                expenseRes.currencyId = expenseJSON[i].currencyId;
                                expenseRes.particulars = expenseJSON[i].particulars;
                                expenseRes.expenseTypeId = expenseJSON[i].expenseTypeId;
                                expenseRes.currencySymbol = expenseJSON[i].currencySymbol;
                                expenseRes.expenseTypeTitle = expenseJSON[i].expenseTypeTitle;
                                expenseRes.attachment = (expenseJSON[i].attachment) ? JSON.parse(expenseJSON[i].attachment) : "" ;
                            output.push(expenseRes);
                        }
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = {
                            expenseList : output
                        };
                        res.status(200).json(response);
                    }
                    else if(!err){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = null;
                        res.status(200).json(response);
                    }
                    else{
                        response.status = false;
                        response.message = "Error while getting data list";
                        response.error = null;
                        response.data = null;
                        res.status(500).json(response);
                    }
                });
            }
            else{
                res.status(401).json(response);
            }
        });
    }

};

LoginCtrl.getAttendanceRequestList = function(req,res,next){
    var response = {
        status : false,
        message : "Invalid credentials",
        data : null,
        error : null
    };
    var validationFlag = true;

    // req.query.APIKey = req.query.APIKey ? req.query.APIKey : "";
    req.query.EZEOneId = req.query.EZEOneId ? req.query.EZEOneId : "";
    req.query.password = req.query.password ? req.query.password : "";
    req.query.token = req.query.token ? req.query.token : "";

    if (!req.query.APIKey)
    {
        error.APIKey = 'Invalid APIKey';
        validationFlag *= false;
    }

    if (!validationFlag){
        response.error = error;
        response.message = 'Please check the errors';
        res.status(400).json(response);
        console.log(response);
    }
    else {
        req.st.validateHEToken(req.query.APIKey,req.query.EZEOneId,req.query.password,req.query.token,function(err,tokenResult){
            if((!err) && tokenResult){

                req.query.status = req.query.status ? req.query.status : 0;
                req.query.startDate = req.query.startDate ? req.query.startDate : null;
                req.query.endDate = req.query.endDate ? req.query.endDate : null;
                req.query.pageNo = (req.query.pageNo) ? (req.query.pageNo):1;
                req.query.limit = (req.query.limit) ? (req.query.limit):100;

                var procParams = [
                    req.st.db.escape(req.query.status),
                    req.st.db.escape(req.query.startDate),
                    req.st.db.escape(req.query.endDate),
                    req.st.db.escape(req.query.APIKey),
                    req.st.db.escape(req.query.pageNo),
                    req.st.db.escape(req.query.limit),
                    req.st.db.escape(tokenResult[0].masterid)
                ];
                /**
                 * Calling procedure to save form template
                 * @type {string}
                 */
                var procQuery = 'CALL WhatMate_get_AttendanceRequests( ' + procParams.join(',') + ')';
                console.log(procQuery);
                req.db.query(procQuery,function(err,attendanceList){
                    if(!err && attendanceList && attendanceList[0]){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = {
                            attendanceList : attendanceList[0],
                            count : attendanceList[1][0].count
                        };
                        res.status(200).json(response);
                    }
                    else if(!err){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = null ;
                        res.status(200).json(response);
                    }
                    else{
                        response.status = false;
                        response.message = "Error while getting data list";
                        response.error = null;
                        response.data = null;
                        res.status(500).json(response);
                    }
                });
            }
            else{
                res.status(401).json(response);
            }
        });
    }

};

LoginCtrl.getLeaveRegister = function(req,res,next){
    var response = {
        status : false,
        message : "Invalid credentials",
        data : null,
        error : null
    };
    var validationFlag = true;

    // req.query.APIKey = req.query.APIKey ? req.query.APIKey : "";
    req.query.EZEOneId = req.query.EZEOneId ? req.query.EZEOneId : "";
    req.query.password = req.query.password ? req.query.password : "";
    req.query.token = req.query.token ? req.query.token : "";

    if (!req.query.APIKey)
    {
        error.APIKey = 'Invalid APIKey';
        validationFlag *= false;
    }

    if (!validationFlag){
        response.error = error;
        response.message = 'Please check the errors';
        res.status(400).json(response);
        console.log(response);
    }
    else {
        req.st.validateHEToken(req.query.APIKey,req.query.EZEOneId,req.query.password,req.query.token,function(err,tokenResult){
            if((!err) && tokenResult){

                req.query.status = req.query.status ? req.query.status : 0;
                req.query.startDate = req.query.startDate ? req.query.startDate : null;
                req.query.endDate = req.query.endDate ? req.query.endDate : null;
                req.query.pageNo = (req.query.pageNo) ? (req.query.pageNo):1;
                req.query.limit = (req.query.limit) ? (req.query.limit):100;

                var procParams = [
                    req.st.db.escape(req.query.status),
                    req.st.db.escape(req.query.startDate),
                    req.st.db.escape(req.query.endDate),
                    req.st.db.escape(req.query.APIKey),
                    req.st.db.escape(req.query.pageNo),
                    req.st.db.escape(req.query.limit),
                    req.st.db.escape(tokenResult[0].masterid)
                ];
                /**
                 * Calling procedure to save form template
                 * @type {string}
                 */
                var procQuery = 'CALL WhatMate_get_leaves( ' + procParams.join(',') + ')';
                console.log(procQuery);
                req.db.query(procQuery,function(err,leaveRegister){
                    if(!err && leaveRegister && leaveRegister[0]){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = {
                            leaveRegister : leaveRegister[0],
                            count : leaveRegister[1][0].count
                        };
                        res.status(200).json(response);
                    }
                    else if(!err){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = null ;
                        res.status(200).json(response);
                    }
                    else{
                        response.status = false;
                        response.message = "Error while getting data list";
                        response.error = null;
                        response.data = null;
                        res.status(500).json(response);
                    }
                });
            }
            else{
                res.status(401).json(response);
            }
        });
    }

};

LoginCtrl.getTravelRequest = function(req,res,next){
    var response = {
        status : false,
        message : "Invalid credentials",
        data : null,
        error : null
    };
    var validationFlag = true;

    // req.query.APIKey = req.query.APIKey ? req.query.APIKey : "";
    req.query.EZEOneId = req.query.EZEOneId ? req.query.EZEOneId : "";
    req.query.password = req.query.password ? req.query.password : "";
    req.query.token = req.query.token ? req.query.token : "";

    if (!req.query.APIKey)
    {
        error.APIKey = 'Invalid APIKey';
        validationFlag *= false;
    }

    if (!validationFlag){
        response.error = error;
        response.message = 'Please check the errors';
        res.status(400).json(response);
        console.log(response);
    }
    else {
        req.st.validateHEToken(req.query.APIKey,req.query.EZEOneId,req.query.password,req.query.token,function(err,tokenResult){
            if((!err) && tokenResult){

                req.query.status = req.query.status ? req.query.status : 0;
                req.query.startDate = req.query.startDate ? req.query.startDate : null;
                req.query.endDate = req.query.endDate ? req.query.endDate : null;
                req.query.pageNo = (req.query.pageNo) ? (req.query.pageNo):1;
                req.query.limit = (req.query.limit) ? (req.query.limit):100;

                var procParams = [
                    req.st.db.escape(req.query.status),
                    req.st.db.escape(req.query.startDate),
                    req.st.db.escape(req.query.endDate),
                    req.st.db.escape(req.query.APIKey),
                    req.st.db.escape(req.query.pageNo),
                    req.st.db.escape(req.query.limit),
                    req.st.db.escape(tokenResult[0].masterid)
                ];
                /**
                 * Calling procedure to save form template
                 * @type {string}
                 */
                var procQuery = 'CALL WhatMate_get_TravelRequest( ' + procParams.join(',') + ')';
                console.log(procQuery);
                req.db.query(procQuery,function(err,travelRequest){
                    if(!err && travelRequest && travelRequest[0]){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = {
                            travelRequest : travelRequest[0],
                            count : travelRequest[1][0].count
                        };
                        res.status(200).json(response);
                    }
                    else if(!err){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = null ;
                        res.status(200).json(response);
                    }
                    else{
                        response.status = false;
                        response.message = "Error while getting data list";
                        response.error = null;
                        response.data = null;
                        res.status(500).json(response);
                    }
                });
            }
            else{
                res.status(401).json(response);
            }
        });
    }

};

LoginCtrl.getTravelClaim = function(req,res,next){
    var response = {
        status : false,
        message : "Invalid credentials",
        data : null,
        error : null
    };
    var validationFlag = true;

    // req.query.APIKey = req.query.APIKey ? req.query.APIKey : "";
    req.query.EZEOneId = req.query.EZEOneId ? req.query.EZEOneId : "";
    req.query.password = req.query.password ? req.query.password : "";
    req.query.token = req.query.token ? req.query.token : "";

    if (!req.query.APIKey)
    {
        error.APIKey = 'Invalid APIKey';
        validationFlag *= false;
    }

    if (!validationFlag){
        response.error = error;
        response.message = 'Please check the errors';
        res.status(400).json(response);
        console.log(response);
    }
    else {
        req.st.validateHEToken(req.query.APIKey,req.query.EZEOneId,req.query.password,req.query.token,function(err,tokenResult){
            if((!err) && tokenResult){

                req.query.status = req.query.status ? req.query.status : 0;
                req.query.startDate = req.query.startDate ? req.query.startDate : null;
                req.query.endDate = req.query.endDate ? req.query.endDate : null;
                req.query.pageNo = (req.query.pageNo) ? (req.query.pageNo):1;
                req.query.limit = (req.query.limit) ? (req.query.limit):100;

                var procParams = [
                    req.st.db.escape(req.query.status),
                    req.st.db.escape(req.query.startDate),
                    req.st.db.escape(req.query.endDate),
                    req.st.db.escape(req.query.APIKey),
                    req.st.db.escape(req.query.pageNo),
                    req.st.db.escape(req.query.limit),
                    req.st.db.escape(tokenResult[0].masterid)
                ];
                /**
                 * Calling procedure to save form template
                 * @type {string}
                 */
                var procQuery = 'CALL WhatMate_get_TravelClaim( ' + procParams.join(',') + ')';
                console.log(procQuery);
                req.db.query(procQuery,function(err,travelClaim){
                    if(!err && travelClaim && travelClaim[0]){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = {
                            travelClaim : travelClaim[0],
                            count : travelClaim[1][0].count
                        };
                        res.status(200).json(response);
                    }
                    else if(!err){
                        response.status = true;
                        response.message = "Data loaded successfully";
                        response.error = null;
                        response.data = null ;
                        res.status(200).json(response);
                    }
                    else{
                        response.status = false;
                        response.message = "Error while getting data list";
                        response.error = null;
                        response.data = null;
                        res.status(500).json(response);
                    }
                });
            }
            else{
                res.status(401).json(response);
            }
        });
    }

};


module.exports = LoginCtrl;