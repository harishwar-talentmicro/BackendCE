/**
 * Created by Jana1 on 06-04-2017.
 */

var express = require('express');
var router = express.Router();

var loginCtrl = require('./dataview-ctrl');

router.post('/login',loginCtrl.login);
router.get('/HEUsers',loginCtrl.getHelloEZEUsers);
router.get('/task',loginCtrl.getTasks);
router.get('/meeting',loginCtrl.getMeeting);
router.get('/expense',loginCtrl.getExpenseList);

router.get('/expense/details',loginCtrl.getExpenseDetails);

router.get('/master/status',loginCtrl.getFormStatus);
router.get('/attendanceRequest',loginCtrl.getAttendanceRequestList);
router.get('/leaveRegister',loginCtrl.getLeaveRegister);
router.get('/travelRequest',loginCtrl.getTravelRequest);
router.get('/travelClaim',loginCtrl.getTravelClaim);

module.exports = router;
