var st = null;

function NotificationQueryManager(db,stdLib){
    if(stdLib){
        st = stdLib;
    }
};

/**
 * Checks if the logged in user is admin of this group or not
 * @param token
 * @param groupId
 * @param isGroupAdminCallback (err,result)
 *  err : Error in execution of query , result : boolean (true if isAdmin and false if not an admin)
 */
NotificationQueryManager.prototype.isGroupAdminByToken = function(token,groupId,isGroupAdminCallback){

    if((typeof(isGroupAdminCallback)).toString() !== "function"){
        isGroupAdminCallback = function(error,res){
            console.log('No callback passed to isGroupAdminByToken');
            if(error){
                console.log('Error in isGroupAdminByToken');
                console.log(error);
            }
            else{
                console.log(res);
            }
        };
    }

    if(token && groupId){
        var query = "SELECT tid FROM tmgroups WHERE tid = "+ st.db.escape(groupId) + " AND AdminID = " +
            " (SELECT masterid FROM tloginout WHERE token = "+ st.db.escape(token) + " LIMIT 1)";

        console.log(query);

        st.db.query(query,function(err,results){
            if(err){
                console.log('Error in isGroupAdminByToken');
                console.log(err);
                isGroupAdminCallback(err,null);
            }
            else{
                if(results){
                    if(results[0]){
                        isGroupAdminCallback(null,true);
                    }
                    else{
                        isGroupAdminCallback(null,false);
                    }
                }
            }
        });
    }

};

/**
 * Checks if the logged in user is admin of this group or not
 * @param token
 * @param groupId
 * @param isGroupAdminCallback (err,result)
 *  err : Error in execution of query , result : boolean (true if isAdmin and false if not an admin)
 */
NotificationQueryManager.prototype.getIndividualGroupId = function(masterId,getIndividualGroupIdCallback){

    if((typeof(getIndividualGroupIdCallback)).toString() !== "function"){
        getIndividualGroupIdCallback = function(error,res){
            console.log('No callback passed to getIndividualGroupIdCallback');
            if(error){
                console.log('Error in getIndividualGroupIdCallback');
                console.log(error);
            }
            else{
                console.log(res);
            }
        };
    }

    if(masterId){
        var query = "SELECT tid FROM tmgroups WHERE AdminID = " +
            " "+ st.db.escape(masterId) + " LIMIT 1";

        console.log(query);
        st.db.query(query,function(err,results){
            if(err){
                console.log('Error in getIndividualGroupId');
                console.log(err);
                getIndividualGroupIdCallback(err,null);
            }
            else{
                if(results){
                    if(results[0]){
                        getIndividualGroupIdCallback(null,results[0]);
                    }
                    else{
                        getIndividualGroupIdCallback(null,null);
                    }
                }
            }
        });
    }

};


/**
 * Checks if the logged in user is admin of this group or not
 * @param masterId
 * @param getEzeidDetailsCallback (err,result)
 *  err : Error in execution of query , result : boolean (true if isAdmin and false if not an admin)
 */
NotificationQueryManager.prototype.getEzeidDetails = function(masterId,receiverId,getEzeidDetailsCallback){

    if((typeof(getEzeidDetailsCallback)).toString() !== "function"){
        getEzeidDetailsCallback = function(error,res){
            console.log('No callback passed to getEzeidDetails');
            if(error){
                console.log('Error in getEzeidDetails');
                console.log(error);
            }
            else{
                console.log(res);
            }
        };
    }

    if(masterId){
        var query = "SELECT ezeid,IPhoneDeviceID AS iphoneId FROM tmaster WHERE tid = "+ st.db.escape(masterId) + " LIMIT 1";

        console.log(query);

        st.db.query(query,function(err,results){
            if(err){
                console.log('Error in getEzeidDetails');
                console.log(err);
                getEzeidDetailsCallback(err,null);
            }
            else{
                if(results){
                    if(results[0]){
                        getEzeidDetailsCallback(null,results[0],receiverId);
                    }
                    else{
                        getEzeidDetailsCallback(null,null,receiverId);
                    }
                }
            }
        });
    }

};


/**
 * Checks if the logged in user is admin of this group or not
 * @param masterId
 * @param getEzeidDetailsCallback (err,result)
 *  err : Error in execution of query , result : boolean (true if isAdmin and false if not an admin)
 */
NotificationQueryManager.prototype.getIphoneId = function(masterId,getIphoneIdCallback){

    if((typeof(getIphoneIdCallback)).toString() !== "function"){
        getIphoneIdCallback = function(error,res){
            console.log('No callback passed to getIphoneId');
            if(error){
                console.log('Error in getIphoneId');
                console.log(error);
            }
            else{
                console.log(res);
            }
        };
    }

    if(masterId){
        var query = "SELECT IPhoneDeviceID FROM tmaster WHERE tid = "+ st.db.escape(masterId) + " LIMIT 1";

        console.log(query);

        st.db.query(query,function(err,results){
            if(err){
                console.log('Error in getIphoneId');
                console.log(err);
                getIphoneIdCallback(err,null);
            }
            else{
                if(results){
                    if(results[0]){
                        getIphoneIdCallback(null,results[0]);
                    }
                    else{
                        getIphoneIdCallback(null,null);
                    }
                }
            }
        });
    }

};



NotificationQueryManager.prototype.getGroupInfo = function(groupId,groupType,getGroupInfoCallback){
    if((typeof(getGroupInfoCallback)).toString() !== "function"){
        getGroupInfoCallback = function(error,res){
            console.log('No callback passed to getGroupInfo');
            if(error){
                console.log('Error in getGroupInfo');
                console.log(error);
            }
            else{
                console.log(res);
            }
        };
    }


    var queryParams = st.db.escape(groupId)+','+st.db.escape(groupType);
    var query = 'CALL pGetGroupInfn(' + queryParams + ')';

    st.db.query(query, function (err, getResult) {
        if (!err) {
            if (getResult) {
                if (getResult[0]) {
                    if (getResult[0].length > 0){
                        if(getResult[0][0]){
                            if(getResult[0][0]){
                                getGroupInfoCallback(null,getResult[0][0]);
                            }
                            else{
                                getGroupInfoCallback(null,null);
                            }
                        }
                        else{
                            getGroupInfoCallback(null,null);
                        }

                    }
                    else{
                        getGroupInfoCallback(null,null);
                    }

                }
                else{
                    getGroupInfoCallback(null,null);
                }

            }
            else{
                getGroupInfoCallback(null,null);
            }

        }
        else{
            getGroupInfoCallback(err,null);
        }
    })
};


module.exports = NotificationQueryManager;